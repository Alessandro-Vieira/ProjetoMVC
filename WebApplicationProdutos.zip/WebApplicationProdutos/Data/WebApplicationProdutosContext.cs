﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using WebApplicationProdutos.Models;

namespace WebApplicationProdutos.Data
{
    public class WebApplicationProdutosContext : DbContext
    {
        public WebApplicationProdutosContext (DbContextOptions<WebApplicationProdutosContext> options)
            : base(options)
        {
        }

        public DbSet<WebApplicationProdutos.Models.produto>? produto { get; set; }
    }
}

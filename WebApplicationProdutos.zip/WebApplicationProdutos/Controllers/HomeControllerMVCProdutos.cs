﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplicationProdutos.Controllers
{
    public class HomeControllerMVCProdutos : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Welcome(string nome, int numTimes = 1)
        {
            ViewData["Messagem"] = "Hello " + nome;
            ViewData["NumTimes"] = numTimes;

            return View();

        }
    }
}
